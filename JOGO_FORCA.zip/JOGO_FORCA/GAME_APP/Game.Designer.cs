﻿namespace GAME_APP
{
    partial class Game
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Game));
            this.PnPalavra = new System.Windows.Forms.Panel();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.LbDica = new System.Windows.Forms.Label();
            this.PnLetra = new System.Windows.Forms.Panel();
            this.BtnJogar = new System.Windows.Forms.Button();
            this.TxtLetra = new System.Windows.Forms.TextBox();
            this.LbLetra = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.PbBoneco = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.LbCronometro = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.LbLetras = new System.Windows.Forms.Label();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.CbMusica = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.PnLetra.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PbBoneco)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.SuspendLayout();
            // 
            // PnPalavra
            // 
            this.PnPalavra.BackColor = System.Drawing.Color.Transparent;
            this.PnPalavra.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PnPalavra.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.PnPalavra.Location = new System.Drawing.Point(212, 68);
            this.PnPalavra.Name = "PnPalavra";
            this.PnPalavra.Size = new System.Drawing.Size(714, 113);
            this.PnPalavra.TabIndex = 1;
            this.PnPalavra.UseWaitCursor = true;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(54, 210);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(65, 38);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 6;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.UseWaitCursor = true;
            // 
            // LbDica
            // 
            this.LbDica.BackColor = System.Drawing.Color.MidnightBlue;
            this.LbDica.Font = new System.Drawing.Font("Ravie", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LbDica.ForeColor = System.Drawing.Color.SeaShell;
            this.LbDica.Location = new System.Drawing.Point(212, 42);
            this.LbDica.Name = "LbDica";
            this.LbDica.Size = new System.Drawing.Size(714, 26);
            this.LbDica.TabIndex = 0;
            this.LbDica.Text = "DICA DA PALAVRA:";
            this.LbDica.UseWaitCursor = true;
            this.LbDica.Click += new System.EventHandler(this.LbDica_Click);
            // 
            // PnLetra
            // 
            this.PnLetra.BackColor = System.Drawing.Color.Transparent;
            this.PnLetra.Controls.Add(this.BtnJogar);
            this.PnLetra.Controls.Add(this.TxtLetra);
            this.PnLetra.Controls.Add(this.LbLetra);
            this.PnLetra.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.PnLetra.Location = new System.Drawing.Point(12, 42);
            this.PnLetra.Name = "PnLetra";
            this.PnLetra.Size = new System.Drawing.Size(177, 139);
            this.PnLetra.TabIndex = 2;
            this.PnLetra.UseWaitCursor = true;
            // 
            // BtnJogar
            // 
            this.BtnJogar.BackColor = System.Drawing.Color.LightSkyBlue;
            this.BtnJogar.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.BtnJogar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnJogar.Font = new System.Drawing.Font("Ravie", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnJogar.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BtnJogar.Location = new System.Drawing.Point(0, 67);
            this.BtnJogar.Name = "BtnJogar";
            this.BtnJogar.Size = new System.Drawing.Size(177, 72);
            this.BtnJogar.TabIndex = 2;
            this.BtnJogar.Text = "JOGAR";
            this.BtnJogar.UseVisualStyleBackColor = false;
            this.BtnJogar.UseWaitCursor = true;
            this.BtnJogar.Click += new System.EventHandler(this.BtnJogar_Click);
            // 
            // TxtLetra
            // 
            this.TxtLetra.BackColor = System.Drawing.Color.AliceBlue;
            this.TxtLetra.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.TxtLetra.Dock = System.Windows.Forms.DockStyle.Top;
            this.TxtLetra.Font = new System.Drawing.Font("Ravie", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtLetra.ForeColor = System.Drawing.Color.Black;
            this.TxtLetra.Location = new System.Drawing.Point(0, 26);
            this.TxtLetra.MaxLength = 1;
            this.TxtLetra.Name = "TxtLetra";
            this.TxtLetra.Size = new System.Drawing.Size(177, 35);
            this.TxtLetra.TabIndex = 1;
            this.TxtLetra.Text = "A";
            this.TxtLetra.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.TxtLetra.UseWaitCursor = true;
            // 
            // LbLetra
            // 
            this.LbLetra.BackColor = System.Drawing.Color.MidnightBlue;
            this.LbLetra.Dock = System.Windows.Forms.DockStyle.Top;
            this.LbLetra.ForeColor = System.Drawing.Color.SeaShell;
            this.LbLetra.Location = new System.Drawing.Point(0, 0);
            this.LbLetra.Name = "LbLetra";
            this.LbLetra.Size = new System.Drawing.Size(177, 26);
            this.LbLetra.TabIndex = 0;
            this.LbLetra.Text = "LETRA:";
            this.LbLetra.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.LbLetra.UseWaitCursor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(-7, 250);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(252, 311);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.UseWaitCursor = true;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(287, 384);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(87, 84);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 3;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.UseWaitCursor = true;
            // 
            // PbBoneco
            // 
            this.PbBoneco.BackColor = System.Drawing.Color.Transparent;
            this.PbBoneco.Location = new System.Drawing.Point(111, 295);
            this.PbBoneco.Name = "PbBoneco";
            this.PbBoneco.Size = new System.Drawing.Size(153, 173);
            this.PbBoneco.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PbBoneco.TabIndex = 4;
            this.PbBoneco.TabStop = false;
            this.PbBoneco.UseWaitCursor = true;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(737, 210);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(101, 83);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 5;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.UseWaitCursor = true;
            // 
            // LbCronometro
            // 
            this.LbCronometro.BackColor = System.Drawing.Color.Transparent;
            this.LbCronometro.Font = new System.Drawing.Font("Ravie", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LbCronometro.ForeColor = System.Drawing.Color.SkyBlue;
            this.LbCronometro.Location = new System.Drawing.Point(854, 1);
            this.LbCronometro.Name = "LbCronometro";
            this.LbCronometro.Size = new System.Drawing.Size(87, 41);
            this.LbCronometro.TabIndex = 7;
            this.LbCronometro.Text = "40";
            this.LbCronometro.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.LbCronometro.UseWaitCursor = true;
            this.LbCronometro.Click += new System.EventHandler(this.LbCronometro_Click);
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // LbLetras
            // 
            this.LbLetras.BackColor = System.Drawing.Color.LightSkyBlue;
            this.LbLetras.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LbLetras.ForeColor = System.Drawing.Color.Black;
            this.LbLetras.Location = new System.Drawing.Point(519, 477);
            this.LbLetras.Name = "LbLetras";
            this.LbLetras.Size = new System.Drawing.Size(422, 72);
            this.LbLetras.TabIndex = 9;
            this.LbLetras.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.LbLetras.UseWaitCursor = true;
            this.LbLetras.Click += new System.EventHandler(this.LbLetras_Click);
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(839, 12);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(26, 24);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 8;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.UseWaitCursor = true;
            this.pictureBox5.Click += new System.EventHandler(this.pictureBox5_Click);
            // 
            // CbMusica
            // 
            this.CbMusica.AutoSize = true;
            this.CbMusica.BackColor = System.Drawing.Color.Transparent;
            this.CbMusica.Checked = true;
            this.CbMusica.CheckState = System.Windows.Forms.CheckState.Checked;
            this.CbMusica.ForeColor = System.Drawing.Color.LightSteelBlue;
            this.CbMusica.Location = new System.Drawing.Point(5, 3);
            this.CbMusica.Name = "CbMusica";
            this.CbMusica.Size = new System.Drawing.Size(123, 30);
            this.CbMusica.TabIndex = 10;
            this.CbMusica.Text = "Música";
            this.CbMusica.UseVisualStyleBackColor = false;
            this.CbMusica.CheckedChanged += new System.EventHandler(this.CbMusica_CheckedChanged);
            // 
            // Game
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 26F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkBlue;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(938, 544);
            this.Controls.Add(this.CbMusica);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.LbLetras);
            this.Controls.Add(this.LbCronometro);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.PbBoneco);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.PnLetra);
            this.Controls.Add(this.LbDica);
            this.Controls.Add(this.PnPalavra);
            this.Font = new System.Drawing.Font("Ravie", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(8, 6, 8, 6);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Game";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "JOGO DA FORCA";
            this.UseWaitCursor = true;
            this.Load += new System.EventHandler(this.Game_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.PnLetra.ResumeLayout(false);
            this.PnLetra.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PbBoneco)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel PnPalavra;
        private System.Windows.Forms.Label LbDica;
        private System.Windows.Forms.Panel PnLetra;
        private System.Windows.Forms.Button BtnJogar;
        private System.Windows.Forms.TextBox TxtLetra;
        private System.Windows.Forms.Label LbLetra;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox PbBoneco;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label LbCronometro;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label LbLetras;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.CheckBox CbMusica;
    }
}

