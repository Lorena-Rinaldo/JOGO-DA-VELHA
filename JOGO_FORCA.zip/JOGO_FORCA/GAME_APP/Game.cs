﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using NAudio.Wave;

namespace GAME_APP
{
    public partial class Game : Form
    {
        Forca jogo;
        Label[] Letras;

        public Game()
        {
            InitializeComponent();
        }

        WaveOutEvent EfeitoGrito;

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Game_Load(object sender, EventArgs e)
        {
            CarregarLista(); //carrega a lista de palavras do arquivo de texto
            musica = new SoundPlayer();
            musica.SoundLocation = "fundo.wav";
            musica.PlayLooping();
            NovoJogo();
        }

        private void CarregarLista()
        {
            string arquivo = "lista.txt";
            string[] Linhas = File.ReadAllLines(arquivo); //lerá todas as linhas
            foreach (string linha in Linhas)
            {
                string[] Partes = linha.Split(',');
                Palavras.Add(Partes[0].ToUpper());
                Dicas.Add(Partes[1].ToUpper());
            }
        }

        private void NovoJogo()
        {
            jogo = new Forca(Palavras, Dicas);
            jogo.Sortear();
            LbDica.Text = $"Dica: {jogo.Dicas[jogo.Posicao]}";
            DesenharPalavra(jogo.Palavras[jogo.Posicao]);
            tentativas = 0;
            PbBoneco.Image = null;

            LbCronometro.Text = "40";
            LbLetras.Text = "";
            timer1.Start();
        }

        private void DesenharPalavra(string palavra)
        {
            Letras = new Label[palavra.Length];
            PnPalavra.Controls.Clear();

            int x = 10, y = 10;

            for (int i = 0; i < palavra.Length; i++)
            {
                Letras[i] = new Label();
                Letras[i].Text = "?";
                Letras[i].Height = 50;
                Letras[i].Width = 50;
                Letras[i].ForeColor = Color.Black;
                Letras[i].BackColor = Color.SkyBlue;
                Letras[i].AutoSize=false;
                Letras[i].TextAlign = ContentAlignment.MiddleCenter;
                Letras[i].BorderStyle = BorderStyle.FixedSingle;

                if (i % 10 == 0 && i!=0)
                {
                    y += 50;
                    x = 10;
                }
                Letras[i].Left = x;
                Letras[i].Top = y;
                x += 55;
                PnPalavra.Controls.Add(Letras[i]);
                Letras[i].Show();
            }
        }

        private readonly List <string> Palavras = new List<string>()
        {
            "RADIO", "PARALELEPIPEDO", "MANADA","GATO",
            "ROMA", "JARARACA", "CACIQUE","FUTEBOL",
            "SOCRATES", "ADVOGADO", "DESENVOLVEDOR","AFTA",
            "ALGARISMO", "ANSIOSO", "CARRO", "GRAMPEADOR", 
            "CAMA","ESPINAFRE", "CAMUFLAGEM", "ECOSSISTEMA"

        };
        private readonly List<string> Dicas = new List<string>()
        {
            "Aparelho que transmite som",
            "Pedra usada para fazer calçadas",
            "Grupo de animais, como elefantes",
            "Animal de estimação",
            "Capital da Itália",
            "Uma cobra venenosa",
            "Chefe de uma tribo indígena",
            "Esporte",
            "Famoso filósofo grego",
            "Trabalha com leis",
            "Cria programas de computador",
            "Ferida que aparece na boca",
            "Símbolo que representa um número",
            "Preocupação/Nervosismo",
            "Veículo com quatro rodas",
            "Objeto que prende papéis",
            "Dormir",
            "Comido pelo Popeye",
            "Misturar-se com o ambiente",
            "Conjunto de seres vivos e o ambiente onde vivem"
        };

        private void LbDica_Click(object sender, EventArgs e)
        {

        }

        private void BtnJogar_Click(object sender, EventArgs e)
        {
            string letra = TxtLetra.Text.ToUpper();
            DesenharLetra(letra);
            TxtLetra.Clear();
            TxtLetra.Focus();
        }

        private void DesenharLetra(string letra)
        {
            string palavra = jogo.Palavras[jogo.Posicao];
            bool achou = false;

            if (Char.IsPunctuation(Convert.ToChar(letra))) 
            {
                MessageBox.Show("Caracter inválido");
                return;
            }

            if (LbLetras.Text.Contains(letra))
            {
                MessageBox.Show("Letra já existe");
                return;
            }

            LbLetras.Text+= $"{letra}";

            for (int i = 0; i < palavra.Length; i++)
            {
               if(palavra.Substring(i, 1) == letra)
                {
                    Letras[i].Text = letra;
                    achou = true;
                }
            }
            if (achou == false)
            {
                Gritar();
                DesenharBoneco();
            }
            if(tentativas == 6)
            {
                Derrota();
            }

            Vitoria(); //testa se venceu
        }

        private void Gritar()
        {
            string som = "grito.mp3";
            AudioFileReader somwave = new AudioFileReader(som);
            EfeitoGrito = new WaveOutEvent();
            EfeitoGrito.Init(somwave);
            EfeitoGrito.Play();
        }

        private void Vitoria()
        {
            string palavra = jogo.Palavras[jogo.Posicao];
            string tmp = "";
            foreach (Label letra in Letras) 
            {
                tmp += letra.Text;
            }
            if(tmp.Equals(palavra))
            {
                timer1.Stop();
                MessageBox.Show("Você venceu!!");
                NovoJogo();
            }
        }

        private void Derrota()
        {
            timer1.Stop();
            MessageBox.Show($"Você perdeu. A palavra era: " + $"{jogo.Palavras[jogo.Posicao]}");
            NovoJogo();
        }

        private void DesenharBoneco()
        {
            tentativas++;
            string imagem = $"forca{tentativas}.png";
            PbBoneco.Image = Image.FromFile(imagem);
        }
        int tentativas = 0;
        SoundPlayer musica;

        private void LbCronometro_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            int segundo = Convert.ToInt16(LbCronometro.Text);
            segundo--;
            LbCronometro.Text = segundo.ToString();
            if (segundo == 0)
            {
                Derrota();
            }
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {

        }

        private void LbLetras_Click(object sender, EventArgs e)
        {

        }

        private void CbMusica_CheckedChanged(object sender, EventArgs e)
        {
            if (CbMusica.Checked)
            {
                musica.PlayLooping();
            }
            else
            {
                musica.Stop();
            }
        }
    }
}
