﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GAME_APP
{
    internal class Forca
    {
        public List<string> Palavras { get; set; }
        public List<string> Dicas { get; set; }
        public int Posicao { get; set; }

        public Forca(List<string> Palavras, List<string> Dicas)
        {
            this.Palavras = Palavras;
            this.Dicas = Dicas;
            Posicao = 0;
        }

        public void Sortear()
        {
            Random sorteio = new Random();
            Posicao = sorteio.Next(Palavras.Count());
        }

    }
}
